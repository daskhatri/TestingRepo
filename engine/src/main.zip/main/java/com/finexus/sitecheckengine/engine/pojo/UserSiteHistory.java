package com.finexus.sitecheckengine.engine.pojo;

import java.sql.Time;

import org.springframework.data.annotation.Id;

public class UserSiteHistory {
	
	@Id
	public String id;
	public String userName;
	public String numberOfURLs;
	public String siteURL;
	
	public Time responseTime;
	public Time uptime;
	public Time downTime;
	
	public UserSiteHistory() {}
	
	
	

}
